# Unit tests for the pozyx library

These files require the library ArduinoUnit which can be downloaded here: https://github.com/mmurdoch/arduinounit

