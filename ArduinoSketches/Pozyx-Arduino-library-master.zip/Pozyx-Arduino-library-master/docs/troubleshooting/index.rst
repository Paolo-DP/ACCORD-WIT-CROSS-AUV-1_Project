Troubleshooting
===============

FAQ
---

Lost a device?
--------------

Contacting support
------------------

If you want to contact support, please include the following:

* Run the pozyx_basic_troubleshooting.ino (provide link to github location of script) script and attach its output.
* Mention what you want to achieve. Our support team has experience with many use cases and can set you on the right track.
* If you get an error or exception, please include this in your mail instead of just saying something is broken.

Ultimately, the more information you can provide our support team from the start, the less they'll have to ask of you and the quicker your problem resolution.
